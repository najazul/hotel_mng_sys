#ifndef REVENUE_H
#define REVENUE_H

#include <QWidget>
#include <QFile>
#include <QMessageBox>

namespace Ui {
class revenue;
}

class revenue : public QWidget
{
    Q_OBJECT

public:
    explicit revenue(QWidget *parent = nullptr);
    ~revenue();

protected:
    void showEvent(QShowEvent *event) override;

signals:
    void goBack();

private slots:
    void on_pushButton_clicked();

private:
    Ui::revenue *ui;
};

#endif // REVENUE_H
