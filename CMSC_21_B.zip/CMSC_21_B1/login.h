#ifndef LOGIN_H
#define LOGIN_H

#include "login2.h"
#include <QWidget>
#include <QMessageBox>
#include <QFile>

namespace Ui {
class login;
}

class login : public QWidget
{
    Q_OBJECT

public:
    explicit login(QWidget *parent = nullptr);
    ~login();

protected:

signals:
    void goBack();

private slots:
    void on_pushButton_clicked();
    void on_pushButton_2_clicked();
    void signal_triggered();

private:
    Ui::login *ui;
    login2 *Login2;

};

#endif // LOGIN_H
