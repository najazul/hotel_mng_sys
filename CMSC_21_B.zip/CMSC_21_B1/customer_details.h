#ifndef CUSTOMER_DETAILS_H
#define CUSTOMER_DETAILS_H

#include <QWidget>
#include <QFile>
#include <QMessageBox>

namespace Ui {
class customer_details;
}

class customer_details : public QWidget
{
    Q_OBJECT

public:
    explicit customer_details(QWidget *parent = nullptr);
    ~customer_details();

protected:
    void showEvent(QShowEvent *event) override;

signals:
    void goBack();

private slots:
    void on_pushButton_clicked();

private:
    Ui::customer_details *ui;
};

#endif // CUSTOMER_DETAILS_H
