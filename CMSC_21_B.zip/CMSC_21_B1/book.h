#ifndef BOOK_H
#define BOOK_H

#include "book1.h"
#include <QWidget>
#include <QFile>
#include <QMessageBox>

namespace Ui {
class book;
}

class book : public QWidget
{
    Q_OBJECT

public:
    explicit book(QWidget *parent = nullptr);
    void set_max();
    int numberOfRoomsBooked;

    ~book();

private slots:
    void on_pushButton_clicked();
    void on_pushButton_2_clicked();

private:
    Ui::book *ui;
    book1 *Book1;
    int newMaxRooms;
};

#endif // BOOK_H
