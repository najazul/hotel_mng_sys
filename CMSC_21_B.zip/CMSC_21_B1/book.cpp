#include "book.h"
#include "ui_book.h"

#include "mainwindow.h"

book::book(QWidget *parent)
    : QWidget(parent)
    , ui(new Ui::book),
      Book1(new book1(nullptr, 0))
{
    ui->setupUi(this);
}

book::~book()
{
    delete ui;
}

void book::set_max()
{   
    QFile file("maximum_rooms.txt");
    if (!file.open(QIODevice::ReadOnly | QIODevice::Text)) {
        QMessageBox::warning(this, "Error", "Failed to open file for reading.");
        return;
    }

    QTextStream in(&file);
    numberOfRoomsBooked = 0;

    while (!in.atEnd()) {
    QString line = in.readLine();
    int number_of_rms = line.toInt();
    numberOfRoomsBooked = numberOfRoomsBooked + number_of_rms ;
    }
    file.close();

    if(numberOfRoomsBooked == 6){
        QMessageBox::warning(this, "ERROR BOOKING", "Sorry LanceLodge is fully booked as of now.\n" "Please try again later.");
        return;
    }

    int currentMaxRooms = ui->spinBox->maximum();
    newMaxRooms = currentMaxRooms - numberOfRoomsBooked;

    if (newMaxRooms == 0){
        QMessageBox::warning(this, "ERROR BOOKING", "Sorry LanceLodge is fully booked as of now.\n" "Please try again later.");
    }
    ui->spinBox->setMaximum(newMaxRooms);
}

void book::on_pushButton_clicked()
{
    int spinBoxValue = ui->spinBox->value();
    Book1 = new book1(nullptr, spinBoxValue);
    Book1->show();
    this->close();
}


void book::on_pushButton_2_clicked()
{
    MainWindow *mainwindow = new MainWindow(nullptr);
    mainwindow->show();
    this->close();
}


