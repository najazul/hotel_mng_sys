#include "checkout_admin.h"
#include "ui_checkout_admin.h"

checkout_admin::checkout_admin(QWidget *parent)
    : QWidget(parent)
    , ui(new Ui::checkout_admin)
{
    ui->setupUi(this);
}

checkout_admin::~checkout_admin()
{
    delete ui;
}

void checkout_admin::on_pushButton_clicked()
{
    if(clicked){
    }
    else{
        QString transaction_number = ui->lineEdit->text();
        int transaction_number_int = transaction_number.toInt();
        int count = 0;

        QFile file("check_rooms.txt");
        if (!file.open(QIODevice::ReadOnly | QIODevice::Text)) {
            QMessageBox::warning(this, "Error", "Failed to open check_rooms.txt for writing.");
            return;
        }

        QTextStream in(&file);

        while (!in.atEnd())
        {
            QString line = in.readLine();
            QStringList parts = line.split(",");
            if (parts.size() == 4) {
                trans = parts[0].toInt();
                int TransactionNum = parts[0].toInt();

                if (transaction_number_int == TransactionNum){
                    count = 1;
                }
            }
        }

        file.seek(0);

        if (count == 0){
            QMessageBox::warning(this, "INVALID TRANSACTION NUMBER", "Trasaction number not found.\n" "Please enter a valid one!\n");
            return;
        }
        else{
            total_price = 0;
            indiv_price = 0;
            ui->textBrowser->append("ROOMS BOOKED                STAY_DURATION               PRICE(Php)");
            while (!in.atEnd())
            {
                QString line = in.readLine();
                QStringList parts = line.split(",");
                if (parts.size() == 4) {
                    int TransactionNum = parts[0].toInt();
                    QString Rooms = parts[1];
                    QString Stay_duration = parts[3];

                    if (transaction_number_int == TransactionNum){
                        QString full_deets = Rooms;
                        full_deets += "..........................................";
                        full_deets += Stay_duration;
                        full_deets += ".................................";
                        QString itemNum = Rooms.mid(5);
                        int roomNum = itemNum.toInt();
                        if ((roomNum / 100 )== 1){
                            indiv_price = (Stay_duration.toInt()) * 1000;
                            total_price = total_price + ((Stay_duration.toInt()) * 1000);
                        }
                        else if ((roomNum / 100) == 2){
                            indiv_price = (Stay_duration.toInt()) * 2000;
                            total_price = total_price + ((Stay_duration.toInt()) * 2000);
                        }
                        else {
                            indiv_price = (Stay_duration.toInt()) * 3000;
                            total_price = total_price + ((Stay_duration.toInt()) * 3000);
                        }
                        QString indiv_pricestr = QString::number(indiv_price);
                        full_deets += indiv_pricestr;
                        ui->textBrowser->append(full_deets);
                    }
                }
            }
            QString Total_Bill = "Total Bill......................................................................................";
            QString total_pricestr = QString::number(total_price);
            Total_Bill += total_pricestr;
            ui->textBrowser->append("\n");
            ui->textBrowser->append("*****************************************************************************");
            ui->textBrowser->append(Total_Bill);
            clicked = 1;
        }
        file.close();
    }
}

void checkout_admin::remove_paid_customers(){

    QString transaction_number = ui->lineEdit->text();
    int transaction_number_int = transaction_number.toInt();
    int revenues = total_price;

    QFile file_3("total_revenue.txt");
    if (!file_3.open(QIODevice::Append | QIODevice::Text)) {
        QMessageBox::warning(this, "Error", "Failed to open maximum_rooms.txt for writing.");
        return;
    }
    QDateTime currentDateTime = QDateTime::currentDateTime();
    QString formattedDateTime = currentDateTime.toString("yyyy-MM-dd hh:mm:ss");

    QTextStream out_3(&file_3);
    out_3 << "Date Paid: " << formattedDateTime << "| Total Payment: " << revenues << " PHP" << "| Transaction Number: " << trans << "\n" ;
    file_3.close();

    int count = 0;

    QFile file("check_rooms.txt");
    if (file.open(QIODevice::ReadWrite | QIODevice::Text))
    {
        QTextStream in(&file);
        QStringList remainingLines;

        while (!in.atEnd()) {
            QString line = in.readLine();
            QStringList parts = line.split(",");
            if (parts.size() == 4) {
                int TransactionNum = parts[0].toInt();
                if (transaction_number_int != TransactionNum ){
                    remainingLines << line;
                }
                else{
                    count++;
                }
            }
        }

        file.resize(0);
        file.seek(0);

        QTextStream out(&file);
        for (const QString& remainingLine : remainingLines) {
            out << remainingLine << "\n";
        }
        file.close();

    }

    QFile file_2("maximum_rooms.txt");
    if (!file_2.open(QIODevice::Append | QIODevice::Text)) {
        QMessageBox::warning(this, "Error", "Failed to open maximum_rooms.txt for writing.");
        return;
    }

    QTextStream out_2(&file_2);
    out_2 << "-" << count << "\n";
    file_2.close();
}

void checkout_admin::on_pushButton_2_clicked()
{
    ui->lineEdit->clear();
    ui->textBrowser->clear();
    clicked = 0;
    emit goBack();
}

void checkout_admin::on_pushButton_3_clicked()
{
    if(clicked){
        QMessageBox::information(this, "TRANSACTION SUCCESSFUL", "Thank you for your payment.");
        remove_paid_customers();
        emit goBack();
    }
    else{
        QMessageBox::warning(this, "Payment Error", "Enter a valid a transaction number first!");
        return;
    }
}

