#include "login2.h"
#include "ui_login2.h"

login2::login2(QWidget *parent)
    : QWidget(parent)
    , ui(new Ui::login2),
      Rev(new revenue(nullptr)),
      Cus(new customer_details(nullptr)),
      Check(new checkout_admin(nullptr))

{
    ui->setupUi(this);
    connect(Rev, &revenue::goBack, this, &login2::signal_triggered);
    connect(Cus, &customer_details::goBack, this, &login2::signal_triggered);
    connect(Check, &checkout_admin::goBack, this, &login2::signal_triggered);
}

login2::~login2()
{
    delete ui;
}

void login2::on_pushButton_clicked()
{
    Check->show();
    close();
}

void login2::on_pushButton_2_clicked()
{
    Rev->show();
    close();
}

void login2::on_pushButton_3_clicked()
{
    Cus->show();
    close();
}

void login2::signal_triggered()
{
    Rev->close();
    Cus->close();
    Check->close();
    this->show();
}

void login2::on_pushButton_4_clicked()
{
    emit goBack();
}

