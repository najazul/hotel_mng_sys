#ifndef CHECKOUT2_H
#define CHECKOUT2_H


#include <QDebug>
#include <QWidget>
#include <QMessageBox>
#include <QFile>


namespace Ui {
class checkout2;
}

class checkout2 : public QWidget
{
    Q_OBJECT

public:
    explicit checkout2(QWidget *parent = nullptr);
    int Transaction_Number;

    ~checkout2();

signals:
    void goBack();

protected:
    void showEvent(QShowEvent *event) override;

private slots:
    void on_pushButton_clicked();
    void on_pushButton_2_clicked();

private:
    Ui::checkout2 *ui;
    int trans;
    int get_total_price();
    void remove_paid_customers();


};

#endif // CHECKOUT2_H
