#ifndef CHECKOUT_H
#define CHECKOUT_H

#include <QWidget>
#include "checkout2.h"

namespace Ui {
class checkout;
}

class checkout : public QWidget
{
    Q_OBJECT

public:

    explicit checkout(QWidget *parent = nullptr);
    ~checkout();

signals:
    void goBack();

private slots:
    void on_pushButton_clicked();
    void on_pushButton_2_clicked();
    void signal_triggered();
    void on_pushButton_3_clicked();

private:
    Ui::checkout *ui;
    checkout2 *Checkout2;
    bool clicked = 0;
};

#endif // CHECKOUT_H
