#include "checkout.h"
#include "ui_checkout.h"

checkout::checkout(QWidget *parent)
    : QWidget(parent)
    , ui(new Ui::checkout),
    Checkout2(new checkout2(nullptr))
{
    ui->setupUi(this);
    connect(Checkout2, &checkout2::goBack, this, &checkout::signal_triggered);
}

checkout::~checkout()
{
    delete ui;
}


void checkout::on_pushButton_clicked()
{
    if(clicked){
    }
    else{
    QString transaction_number = ui->lineEdit->text();
    int transaction_number_int = transaction_number.toInt();
    int count = 0;

    QFile file("check_rooms.txt");
    if (!file.open(QIODevice::ReadOnly | QIODevice::Text)) {
        QMessageBox::warning(this, "Error", "Failed to open check_rooms.txt for writing.");
        return;
    }

    QTextStream in(&file);

    while (!in.atEnd())
    {
        QString line = in.readLine();
        QStringList parts = line.split(",");
        if (parts.size() == 4) {
            int TransactionNum = parts[0].toInt();

            if (transaction_number_int == TransactionNum){
                count = 1;
            }
        }
    }

    file.seek(0);

    if (count == 0){
        QMessageBox::warning(this, "INVALID TRANSACTION NUMBER", "Trasaction number not found.\n" "Please enter a valid one!\n");
        return;
    }
    else{
        int total_price = 0;
        int indiv_price = 0;
        ui->textBrowser->append("ROOMS BOOKED                STAY_DURATION               PRICE(Php)");
        while (!in.atEnd())
        {
            QString line = in.readLine();
            QStringList parts = line.split(",");
            if (parts.size() == 4) {
                int TransactionNum = parts[0].toInt();
                QString Rooms = parts[1];
                QString Stay_duration = parts[3];

                if (transaction_number_int == TransactionNum){
                    QString full_deets = Rooms;
                    full_deets += "..........................................";
                    full_deets += Stay_duration;
                    full_deets += ".................................";
                    QString itemNum = Rooms.mid(5);
                    int roomNum = itemNum.toInt();
                    if ((roomNum / 100 )== 1){
                        indiv_price = (Stay_duration.toInt()) * 1000;
                        total_price = total_price + ((Stay_duration.toInt()) * 1000);
                    }
                    else if ((roomNum / 100) == 2){
                        indiv_price = (Stay_duration.toInt()) * 2000;
                        total_price = total_price + ((Stay_duration.toInt()) * 2000);
                    }
                    else {
                        indiv_price = (Stay_duration.toInt()) * 3000;
                        total_price = total_price + ((Stay_duration.toInt()) * 3000);
                    }
                    QString indiv_pricestr = QString::number(indiv_price);
                    full_deets += indiv_pricestr;
                    ui->textBrowser->append(full_deets);
                }
            }
        }
        QString Total_Bill = "Total Bill......................................................................................";
        QString total_pricestr = QString::number(total_price);
        Total_Bill += total_pricestr;
        ui->textBrowser->append("\n");
        ui->textBrowser->append("*****************************************************************************");
        ui->textBrowser->append(Total_Bill);
        clicked = 1;
    }
    file.close();
    }
}

void checkout::on_pushButton_2_clicked()
{
    ui->lineEdit->clear();
    ui->textBrowser->clear();
    clicked = 0;
    emit goBack(); 
}

void checkout::signal_triggered()
{
    Checkout2->close();
    this->show();
}

void checkout::on_pushButton_3_clicked()
{
    if(clicked){
        QString transaction_number = ui->lineEdit->text();
        int transaction_number_int = transaction_number.toInt();
        Checkout2->Transaction_Number = transaction_number_int;
        Checkout2->show();
        close();
    }
    else{
        QMessageBox::warning(this, "Payment Error", "Enter a valid a transaction number first!");
        return;
    }
}

