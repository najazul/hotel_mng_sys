#ifndef BOOK1_H
#define BOOK1_H

#include <QWidget>
#include <QListWidget>
#include <QDir>
#include <QMessageBox>
#include <QFile>

namespace Ui {
class book1;
}

class book1 : public QWidget
{
    Q_OBJECT

public:
    explicit book1(QWidget *parent = nullptr);
    book1(QWidget *parent = nullptr, int Value = 0);
    QListWidget* getListWidget() const;
    ~book1();

protected:
    void showEvent(QShowEvent *event) override;

private slots:
    void on_pushButton_clicked();
    void on_pushButton_2_clicked();

private:
    Ui::book1 *ui;
    int maxrooms;
    void check_booked_rooms();
};

#endif // BOOK1_H
