#include "mainwindow.h"
#include <QApplication>

int main(int argc, char *argv[]) {
    QApplication a(argc, argv);

    // Define your style sheet
    QString styleSheet = "QWidget {background-color:#914450}"
                         "QPushButton {background-color: maroon; color: white; font: 600 12pt \"Bodoni MT\"; }"
                         "QTextBrowser {color: white;}"
                         "QSpinBox {color: white;}"
                         "QLineEdit { font-size: 14px; color: white; font: 600 12pt \"Arial\"}"
                         "QLabel { font-size: 14px; color: Black; font: 600 12pt \"Bodoni MT\"}";



    // Set the style sheet for the entire application
    a.setStyleSheet(styleSheet);

    MainWindow w;
    w.show();


    return a.exec();
}
