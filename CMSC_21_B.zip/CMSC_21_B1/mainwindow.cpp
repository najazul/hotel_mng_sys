#include "mainwindow.h"
#include "ui_mainwindow.h"


MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow),
      Book(new book(nullptr)),
      Checkout(new checkout(nullptr)),
      Login(new login(nullptr))

{
    ui->setupUi(this);
    connect(Checkout, &checkout::goBack, this, &MainWindow::signal_triggered);
    connect(Login, &login::goBack, this, &MainWindow::signal_triggered);
}

MainWindow::~MainWindow()
{
    delete ui;
}


void MainWindow::on_pushButton_clicked()
{
    Book->set_max();
    if (Book->numberOfRoomsBooked == 6){
        Book->close();
    }
    else{
        this->close();
        Book->show();
    }
}


void MainWindow::on_pushButton_2_clicked()
{
    this->close();
    Checkout->show();

}

void MainWindow::on_pushButton_3_clicked()
{
    this->close();
    Login->show();
}

void MainWindow::signal_triggered()
{
    Checkout->close();
    Login->close();
    this->show();
}



