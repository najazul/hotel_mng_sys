#include "book1.h"
#include "ui_book1.h"

#include "book2.h"
#include "book.h"

book1::book1(QWidget *parent)
    : QWidget(parent)
    , ui(new Ui::book1)
{
    ui->setupUi(this);
}

book1::book1(QWidget *parent, int Value)
    : QWidget(parent)
    , ui(new Ui::book1)

{
    ui->setupUi(this);
    maxrooms = Value;

    ui->listWidget->setSelectionMode(QAbstractItemView::MultiSelection);
}

book1::~book1()
{
    delete ui;
}

QListWidget* book1::getListWidget() const {
    return ui->listWidget;
}

void book1::check_booked_rooms()
{
    QFile file("check_rooms.txt");
    if (!file.open(QIODevice::ReadOnly | QIODevice::Text)) {
        QMessageBox::warning(this, "Error", "Failed to open file for reading.");
        return;
    }

    QTextStream in(&file);
    while (!in.atEnd()) {
        QString line = in.readLine();
        QStringList parts = line.split(",");
        if (parts.size() == 4) {
            QString itemName = parts[1];
            int room_availability = parts[2].toInt();
            for (int i = 0; i < ui->listWidget->count(); ++i){
                if (ui->listWidget->item(i)->text() == itemName) {
                    if (room_availability == 1){
                    ui->listWidget->item(i)->setFlags(ui->listWidget->item(i)->flags() & ~Qt::ItemIsEnabled);
                    ui->listWidget->item(i)->setFlags(ui->listWidget->item(i)->flags() & ~Qt::ItemIsUserCheckable);
                    ui->listWidget->item(i)->setCheckState(Qt::Checked);
                    }
                }
            }
        }
    }
    file.close();
}

void book1::showEvent(QShowEvent *event)
{
    QWidget::showEvent(event);
    check_booked_rooms();
}

void book1::on_pushButton_clicked()
{

    int checkedCount = 0;
    for (int i = 0; i < ui->listWidget->count(); ++i) {
        if ((ui->listWidget->item(i)->checkState() == Qt::Checked) && (ui->listWidget->item(i)->flags() & Qt::ItemIsEnabled)) {
            checkedCount++;
        }
    }

    if(checkedCount > maxrooms){
        QMessageBox::warning(this, "Selection Limit Exceeded", "Please select only " + QString::number(maxrooms) + " rooms.");
    }
    else if (checkedCount < maxrooms){
        QMessageBox::warning(this, "Selection Limit Not Met", "Please select " + QString::number(maxrooms) + " rooms.");
    }
    else{
        int roomsbooked = maxrooms;
        book2 *Book2= new book2(roomsbooked, this, nullptr);
        Book2->show();
        this->close();
    }

}

void book1::on_pushButton_2_clicked()
{
    book *Book = new book(nullptr);
    Book->set_max();
    Book->show();
    this->close();
}

