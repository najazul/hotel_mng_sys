#ifndef BOOK2_H
#define BOOK2_H

#include "book1.h"
#include "mainwindow.h"
#include <QWidget>
#include <QMessageBox>
//#include <ctime>
#include <QTextStream>
#include <QString>
#include <QFile>
#include <QDir>

namespace Ui {
class book2;
}

class book2 : public QWidget
{
    Q_OBJECT

public:
    explicit book2(int ValueFromBook1Class, book1 *book1, QWidget *parent = nullptr);
    ~book2();

private slots:
    void on_pushButton_clicked();
    void on_pushButton_2_clicked();

private:
    Ui::book2 *ui;
    int roomsbooked;
    QString Randomized();
    book1 *Book1;
    MainWindow *Mainwindow;
};

#endif // BOOK2_H
