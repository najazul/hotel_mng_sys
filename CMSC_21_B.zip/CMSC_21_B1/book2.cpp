#include "book2.h"
#include "ui_book2.h"

#include <QListWidget>

book2::book2(int ValueFromBook1Class, book1 *Book1, QWidget *parent)
    : QWidget(parent),
    ui(new Ui::book2),
    Book1(Book1),
    Mainwindow(new MainWindow(nullptr))
{
    ui->setupUi(this);
    roomsbooked = ValueFromBook1Class;
}

book2::~book2()
{
    delete ui;
}

QString book2::Randomized()
{
    srand(static_cast<unsigned int>(time(0)));
    QString transactionNumber;
    QTextStream stream(&transactionNumber);
    for (int i = 0; i < 7; ++i) {
        stream << rand() % 10;
    }
    return transactionNumber;
}

void book2::on_pushButton_clicked()
{
    QMessageBox::StandardButton reply;
    reply = QMessageBox::question(this, "Confirmation", "Are you sure you want to proceed?",
                                  QMessageBox::Yes|QMessageBox::No);

    if (reply == QMessageBox::Yes) {

    QFile file("transaction_details.txt");
    if (!file.open(QIODevice::ReadWrite | QIODevice::Text)) {
        QMessageBox::warning(this, "Error", "Failed to open transaction_details.txt for writing.");
        return;
    }

    QTextStream in(&file);

    QString transactioncode = Randomized();
    while (!in.atEnd()) {
        QString line = in.readLine();
        QStringList parts = line.split("|");
        if (parts.size() == 5) {
            QString TransactionNum = parts[4];

            if (transactioncode == TransactionNum){
                transactioncode = Randomized();
            }
        }
    }

    QTextStream out(&file);

    out << "Customer Name: " << ui->customer_name->text() << "|"
        << "Contact Number: " << ui->contact_number->text() << "|"
        << "Email Address: " << ui->email_add->text() << "|"
        << "Days of Stay: " << ui->spinBox->value() << "|"
        << "Transaction Number: " << transactioncode << "|"
        << "Number of Rooms Booked: " << roomsbooked << "|"
        << "Room/s Booked: ";

    QListWidget* listWidget = Book1->getListWidget();

    QFile file_2("check_rooms.txt");
    if (!file_2.open(QIODevice::Append | QIODevice::Text)) {
        QMessageBox::warning(this, "Error", "Failed to open check_rooms.txt for writing.");
        return;
    }

    QTextStream out_2(&file_2);

    for (int i = 0; i < listWidget->count(); ++i) {
        QListWidgetItem *items = listWidget->item(i);
        if (items->checkState() == Qt::Checked && (items->flags() & Qt::ItemIsEnabled)) {
            out << items->text() << ",";
            out_2 << transactioncode << "," << items->text() << "," << 1 << "," << ui->spinBox->value() << "\n";
        }
    }

    out << "\n";
    file.close();
    file_2.close();

    QFile file_3("maximum_rooms.txt");
    if (!file_3.open(QIODevice::Append | QIODevice::Text)) {
        QMessageBox::warning(this, "Error", "Failed to open maximum_rooms.txt for writing.");
        return;
    }

    QTextStream out_3(&file_3);
    out_3 << roomsbooked << "\n";
    file_3.close();

    QMessageBox::information(this, "Booked Successfully",
                             "Thank you for booking with us.\n"
                             "Please save this transaction number for checking out: " + transactioncode);

    ui->customer_name->clear();
    //this->close();
    }
    else{
        return;
    }
}

void book2::on_pushButton_2_clicked()
{
    Book1->show();
    this->close();
}

