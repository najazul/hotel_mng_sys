#ifndef LOGIN2_H
#define LOGIN2_H

#include "revenue.h"
#include "customer_details.h"
#include "checkout_admin.h"
#include <QWidget>
#include <QFile>

namespace Ui {
class login2;
}

class login2 : public QWidget
{
    Q_OBJECT

public:
    explicit login2(QWidget *parent = nullptr);
    ~login2();

private slots:
    void on_pushButton_clicked();
    void on_pushButton_2_clicked();
    void on_pushButton_3_clicked();
    void signal_triggered();
    void on_pushButton_4_clicked();

signals:
    void goBack();

private:
    Ui::login2 *ui;
    revenue *Rev;
    customer_details *Cus;
    checkout_admin *Check;
};

#endif // LOGIN2_H
