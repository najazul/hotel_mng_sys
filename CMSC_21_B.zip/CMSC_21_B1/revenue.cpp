#include "revenue.h"
#include "ui_revenue.h"

revenue::revenue(QWidget *parent)
    : QWidget(parent)
    , ui(new Ui::revenue)
{
    ui->setupUi(this);
}

revenue::~revenue()
{
    delete ui;
}

void revenue::showEvent(QShowEvent *event)
{
    QWidget::showEvent(event);

    QFile file("total_revenue.txt");
    if (!file.open(QIODevice::ReadOnly | QIODevice::Text)) {
        QMessageBox::warning(this, "Error", "Failed to open total_revenue.txt for writing.");
        return;
    }

    QTextStream in(&file);
    while (!in.atEnd()) {
        QString line = in.readLine();
        ui->textBrowser->append(line);
        ui->textBrowser->append("\n");
    }
}

void revenue::on_pushButton_clicked()
{
    ui->textBrowser->clear();
    emit goBack();
}

