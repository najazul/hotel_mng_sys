#include "customer_details.h"
#include "ui_customer_details.h"

customer_details::customer_details(QWidget *parent)
    : QWidget(parent)
    , ui(new Ui::customer_details)
{
    ui->setupUi(this);
}

customer_details::~customer_details()
{
    delete ui;
}

void customer_details::showEvent(QShowEvent *event)
{
    QWidget::showEvent(event);
    QFile file("transaction_details.txt");
    if (!file.open(QIODevice::ReadOnly | QIODevice::Text)) {
        QMessageBox::warning(this, "Error", "Failed to open transaction_details.txt for writing.");
        return;
    }
    QTextStream in(&file);
    while (!in.atEnd()) {
        QString line = in.readLine();
        ui->textBrowser->append(line);
        ui->textBrowser->append("\n");
    }
}


void customer_details::on_pushButton_clicked()
{
    ui->textBrowser->clear();
    emit goBack();
}

