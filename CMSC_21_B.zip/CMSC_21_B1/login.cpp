#include "login.h"
#include "ui_login.h"

login::login(QWidget *parent)
    : QWidget(parent)
    , ui(new Ui::login),
      Login2(new login2(nullptr))
{
    ui->setupUi(this);
    connect(Login2, &login2::goBack, this, &login::signal_triggered);
}

login::~login()
{
    delete ui;
}

void login::on_pushButton_clicked()
{
    if((ui->lineEdit->text() == "BhouscksMap4gm4h@l") && ui->lineEdit_2->text() == "Imissyoubalikkana"){
        Login2->show();
        close();
    }
    else{
        QMessageBox::warning(this, "Log-in failed", "Incorrect username or password\n" "Try again");
        return;
    }
}

void login::on_pushButton_2_clicked()
{
    ui->lineEdit->clear();
    ui->lineEdit_2->clear();
    emit goBack();
}

void login::signal_triggered()
{
    Login2->close();
    ui->lineEdit->clear();
    ui->lineEdit_2->clear();
    this->show();
}
