#ifndef CHECKOUT_ADMIN_H
#define CHECKOUT_ADMIN_H

#include <QWidget>
#include <QFile>
#include <QMessageBox>
#include <QDate>

namespace Ui {
class checkout_admin;
}

class checkout_admin : public QWidget
{
    Q_OBJECT

public:
    explicit checkout_admin(QWidget *parent = nullptr);
    ~checkout_admin();

private slots:
    void on_pushButton_clicked();
    void on_pushButton_2_clicked();
    void on_pushButton_3_clicked();

signals:
    void goBack();

private:
    Ui::checkout_admin *ui;
    int total_price = 0;
    int indiv_price = 0;
    bool clicked = 0;
    int trans;
    void remove_paid_customers();
};

#endif // CHECKOUT_ADMIN_H
