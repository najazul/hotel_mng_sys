#include "checkout2.h"
#include "ui_checkout2.h"

#include "mainwindow.h"

checkout2::checkout2(QWidget *parent)
    : QWidget(parent)
    , ui(new Ui::checkout2)
{
    ui->setupUi(this);
}

checkout2::~checkout2()
{
    delete ui;
}

int checkout2::get_total_price(){
    QFile file("check_rooms.txt");
    if (!file.open(QIODevice::ReadOnly | QIODevice::Text)) {
        QMessageBox::warning(this, "Error", "Failed to open check_rooms.txt for writing.");
        return 1;
    }

    int total_price = 0;

    QTextStream in(&file);

    while (!in.atEnd()) {
        QString line = in.readLine();
        QStringList parts = line.split(",");
        if (parts.size() == 4) {
            trans = parts[0].toInt();
            int TransactionNum = parts[0].toInt();
            QString itemName = parts[1];
            int days_of_stay = parts[3].toInt();

            if (Transaction_Number == TransactionNum){
                QString itemNum = itemName.mid(5);
                    int roomNum = itemNum.toInt();
                    if ((roomNum / 100 )== 1){
                        total_price = total_price + (days_of_stay * 1000);
                    }
                    else if ((roomNum / 100) == 2){
                        total_price = total_price + (days_of_stay * 2000);
                    }
                    else {
                        total_price = total_price + (days_of_stay * 3000);
                    }
            }
        }
    }
    file.close();

    return total_price;
}

void checkout2::remove_paid_customers(){

    int revenues = get_total_price();
    QFile file_3("total_revenue.txt");
    if (!file_3.open(QIODevice::Append | QIODevice::Text)) {
        QMessageBox::warning(this, "Error", "Failed to open maximum_rooms.txt for writing.");
        return;
    }
    QDateTime currentDateTime = QDateTime::currentDateTime();
    QString formattedDateTime = currentDateTime.toString("yyyy-MM-dd hh:mm:ss");

    QTextStream out_3(&file_3);
    out_3 << "Date Paid: " << formattedDateTime << "| Total Payment: " << revenues << " PHP" << "| Transaction Number: " << trans << "\n" ;
    file_3.close();

    int count = 0;

    QFile file("check_rooms.txt");
    if (file.open(QIODevice::ReadWrite | QIODevice::Text))
    {
        QTextStream in(&file);
        QStringList remainingLines;

        while (!in.atEnd()) {
            QString line = in.readLine();
            QStringList parts = line.split(",");
            if (parts.size() == 4) {
                int TransactionNum = parts[0].toInt();
                if (Transaction_Number != TransactionNum ){
                    remainingLines << line;
                }
                else{
                    count = count + 1;
                }
            }
        }

        file.resize(0);
        file.seek(0);

        QTextStream out(&file);
        for (const QString& remainingLine : remainingLines) {
            out << remainingLine << "\n";
        }
        file.close();

    }


    QFile file_2("maximum_rooms.txt");
    if (!file_2.open(QIODevice::Append | QIODevice::Text)) {
        QMessageBox::warning(this, "Error", "Failed to open maximum_rooms.txt for writing.");
        return;
    }

    QTextStream out_2(&file_2);
    out_2 << "-" << count << "\n";
    file_2.close();
}


void checkout2::showEvent(QShowEvent *event)
{
    QWidget::showEvent(event);
    int price = get_total_price();
    ui->label_2->setText(QString::number(price));
}

void checkout2::on_pushButton_clicked()
{
    int payment = ui->lineEdit->text().toInt();
    int price = ui->label_2->text().toInt();

    if(price > payment){
        int remaining_bal = price - payment;
        QMessageBox::warning(this, "TRANSACTION CANCELLED", "Insufficient payment. " "Please pay more " +
                            QString::number(remaining_bal) + " to proceed.");
        return;
    }
    else if(price < payment && price != payment){
        int remaining_bal = payment - price;
        QMessageBox::information(this, "TRANSACTION SUCCESFFUL", "Payment EXCEEDED!!\n" "Excess balance of " + QString::number(remaining_bal)
                            + " will be automatically sent to your account immediately!!\n" "Thank you for your payment.");
        remove_paid_customers();
        MainWindow *mymainwindow = new MainWindow(nullptr);
        mymainwindow->show();
        close();
    }
    else{
        QMessageBox::information(this, "TRANSACTION SUCCESSFUL", "Thank you for your payment.");
        remove_paid_customers();
        MainWindow *mymainwindow = new MainWindow(nullptr);
        mymainwindow->show();
        close();
    }
}


void checkout2::on_pushButton_2_clicked()
{
    emit goBack();
}

